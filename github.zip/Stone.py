class Stone(str):
	pass
